### Hexlet tests and linter status:
[![Actions Status](https://github.com/deaniway/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/deaniway/python-project-49/actions)


https://asciinema.org/a/M9esqBQaazplJ9GWvvjedD0rI - запуск и правила игры в угадывании чет/нечет числа!